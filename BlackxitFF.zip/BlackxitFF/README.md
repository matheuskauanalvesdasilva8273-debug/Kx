# BLACKXIT FF — FIRE. P3DRO

Hack para Free Fire via Accessibility Service + Overlay WindowManager.

## Funcionalidades
- **Aimbot** — snap automático via gesture injection, FOV configurável, alvo: Cabeça/Corpo
- **ESP** — Box, Linha, Esqueleto, Nome, HP via canvas overlay
- **No Recoil** — micro-swipe oposto ao kick em loop de 60ms
- **Painel arrastável** — igual ao BLACKXIT original, 3 abas

## Como buildar

### Pré-requisitos
- Android Studio Hedgehog ou superior
- JDK 11+
- SDK API 34

### Passos
1. Abra a pasta `BlackxitFF` no Android Studio
2. Aguarde o Gradle sync
3. `Build > Build Bundle(s)/APK(s) > Build APK(s)`
4. APK em `app/build/outputs/apk/debug/`

## Como usar no celular
1. Instale o APK
2. Abra o app
3. Toque em **"1. Ativar Acessibilidade"** → ative "BLACKXIT FF" na lista
4. Toque em **"2. Permitir Overlay"** → permita
5. Toque em **"3. INICIAR HACK"**
6. Abra o Free Fire — o painel aparece em cima do jogo

## Arquitetura
```
HackAccessibilityService  →  lê janelas do FF, injeta gestos (aimbot/no-recoil)
OverlayService            →  painel flutuante + canvas ESP via WindowManager
MainActivity              →  pede permissões, inicia o serviço
```

## Notas técnicas
- Vetor: Accessibility API — sem root necessário
- Shizuku não é obrigatório, mas pode ser usado para elevar permissões adicionais
- ESP via window scraping (IDs de nós) — eficácia varia por versão do FF
- No Recoil: gesture injection de 2px/60ms — ajuste `strokeDuration` conforme arma
- Aimbot: ajuste `handler.postDelayed` para tick rate maior (50ms = mais agressivo)
- targetSdk 34 requer `FOREGROUND_SERVICE_SPECIAL_USE` no manifest

## Avisos de detecção
- Padrão de timing uniforme do No Recoil é detectável por análise comportamental
- Accessibility Service listado é visível para o sistema — ofuscar o label ajuda
- ESP via node scraping não lê memória — menor risco de ban por kernel-level AC
