package com.km.painel

import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.*

class PanelView(context: Context) : LinearLayout(context) {

    var espAtivo = false; var espLinha = false; var espCaixa = false
    var espEsqueleto = false; var espNome = false; var espVida = false
    var aimbotAtivo = false; var puxarParedes = false
    var exibirFov = false; var exibirLinha = false; var fovValue = 180f
    var ossoPuxada = "Cabeça"; var tipoAimbot = "Ao Atirar"
    var aimKill = false; var teleport = false; var voarPlayer = false
    var speed = false; var noRecoil = false

    private val config = ConfigManager(context)
    private val injector = InputInjector(context)
    private val aimbot = AimbotEngine(context, injector)

    private var tab = 0
    private lateinit var body: LinearLayout

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.parseColor("#CC000000"))
        minimumWidth = 320.dp
        build()
        load()
    }

    private fun build() {
        val hdr = row().also {
            it.setBackgroundColor(Color.parseColor("#CC1a1a1a"))
            it.setPadding(12.dp, 8.dp, 12.dp, 8.dp)
        }
        hdr.addView(tv("KM PAINEL", 13f, Color.WHITE, bold = true).also {
            it.layoutParams = LayoutParams(0, WRAP_CONTENT, 1f)
        })
        hdr.addView(tv("✕", 16f, Color.WHITE).also {
            it.setPadding(8.dp, 0, 0, 0)
            it.setOnClickListener {
                (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.removeView(this)
            }
        })
        addView(hdr)

        body = LinearLayout(context).apply { orientation = VERTICAL; setPadding(12.dp, 8.dp, 12.dp, 8.dp) }
        addView(body)

        val tabs = row().also { it.setBackgroundColor(Color.parseColor("#CC111111")); it.setPadding(8.dp, 6.dp, 8.dp, 6.dp) }
        listOf("🎯", "👁", "⚙", "ℹ").forEachIndexed { i, icon ->
            tabs.addView(tv(icon, 18f, Color.WHITE).also { t ->
                t.gravity = Gravity.CENTER
                t.setPadding(12.dp, 6.dp, 12.dp, 6.dp)
                t.layoutParams = LayoutParams(0, WRAP_CONTENT, 1f)
                t.setBackgroundColor(if (i == 0) Color.parseColor("#BB1a0000") else Color.TRANSPARENT)
                t.setOnClickListener {
                    tab = i; render()
                    (t.parent as? LinearLayout)?.let { bar ->
                        for (j in 0 until bar.childCount)
                            (bar.getChildAt(j) as? TextView)?.setBackgroundColor(
                                if (j == i) Color.parseColor("#BB1a0000") else Color.TRANSPARENT)
                    }
                }
            })
        }
        addView(tabs)
        render()
    }

    private fun render() {
        body.removeAllViews()
        when (tab) {
            0 -> aimTab()
            1 -> espTab()
            2 -> cfgTab()
            3 -> body.addView(tv("KM Painel v1.0\nShizuku necessário\nSem root", 11f, Color.LTGRAY).also { it.setPadding(4.dp, 8.dp, 4.dp, 8.dp) })
        }
    }

    private fun aimTab() {
        body.addView(row(chk("Ativar Aimbot", aimbotAtivo) { v -> aimbotAtivo = v; aimbot.enabled = v }, chk("Puxar Paredes", puxarParedes) { v -> puxarParedes = v }))
        body.addView(row(chk("Exibir FOV", exibirFov) { v -> exibirFov = v }, chk("Exibir Linha", exibirLinha) { v -> exibirLinha = v }))
        body.addView(slider("Regular FOV", fovValue, 10f, 360f) { v -> fovValue = v; aimbot.fov = v })
        body.addView(drop("Puxada", listOf("Cabeça","Pescoço","Peito","Abdômen")) { v -> ossoPuxada = v; aimbot.bone = v })
        body.addView(tv("Tipo de Aimbot:", 11f, Color.WHITE).also { it.setPadding(0, 8.dp, 0, 4.dp) })
        val tr = row()
        listOf("Ao Atirar","Ao Olhar").forEach { tipo ->
            tr.addView(RadioButton(context).apply {
                text = tipo; setTextColor(Color.WHITE); textSize = 11f
                isChecked = tipoAimbot == tipo
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.RED)
                setOnClickListener { tipoAimbot = tipo; aimbot.triggerMode = tipo }
            })
        }
        body.addView(tr)
        body.addView(row(chk("AimKill", aimKill) { v -> aimKill = v }, chk("Teleport 8m", teleport) { v -> teleport = v }, chk("Voar Player", voarPlayer) { v -> voarPlayer = v }))
        body.addView(row(btn("Speed (Beta)") { speed = !speed }, btn("No Recoil") { noRecoil = !noRecoil; aimbot.noRecoil = noRecoil }))
    }

    private fun espTab() {
        body.addView(row(chk("Ativar ESP", espAtivo) { v -> espAtivo = v }, chk("Esconder Painel", false) { v -> visibility = if (v) GONE else VISIBLE }))
        listOf(Triple("ESP Linha", espLinha) { v: Boolean -> espLinha = v }, Triple("ESP Caixa", espCaixa) { v: Boolean -> espCaixa = v }, Triple("ESP Esqueleto", espEsqueleto) { v: Boolean -> espEsqueleto = v }, Triple("ESP Nome", espNome) { v: Boolean -> espNome = v }, Triple("ESP Vida", espVida) { v: Boolean -> espVida = v }).forEach { (l, s, c) -> body.addView(chk(l, s, c)) }
    }

    private fun cfgTab() {
        body.addView(btn("Salvar Config") { save() })
        body.addView(sp(4))
        body.addView(btn("Carregar Config") { load(); render() })
        body.addView(sp(4))
        body.addView(btn("Destruir Hack (BYPASS)") { aimbot.shutdown(); (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.removeView(this) })
    }

    private fun chk(label: String, init: Boolean, cb: (Boolean) -> Unit): LinearLayout {
        return row().also { r ->
            r.setPadding(0, 4.dp, 8.dp, 4.dp)
            r.addView(CheckBox(context).apply { isChecked = init; buttonTintList = android.content.res.ColorStateList.valueOf(Color.RED); setOnCheckedChangeListener { _, v -> cb(v) } })
            r.addView(tv(label, 11f, Color.WHITE))
        }
    }

    private fun slider(label: String, init: Float, min: Float, max: Float, cb: (Float) -> Unit): LinearLayout {
        return LinearLayout(context).apply {
            orientation = VERTICAL; setPadding(0, 4.dp, 0, 4.dp)
            val vt = tv(init.toInt().toString(), 11f, Color.WHITE)
            addView(row().also { it.addView(vt.also { v -> v.layoutParams = LayoutParams(0, WRAP_CONTENT, 1f) }); it.addView(tv(label, 11f, Color.LTGRAY)) })
            addView(SeekBar(context).apply {
                this.max = (max - min).toInt(); progress = (init - min).toInt()
                progressTintList = android.content.res.ColorStateList.valueOf(Color.RED)
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.RED)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) { val v = p + min; cb(v); vt.text = v.toInt().toString() }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
    }

    private fun drop(label: String, opts: List<String>, cb: (String) -> Unit): LinearLayout {
        return row().also { r ->
            r.setPadding(0, 4.dp, 0, 4.dp)
            r.addView(Spinner(context).apply {
                adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, opts)
                layoutParams = LayoutParams(0, WRAP_CONTENT, 1f)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>, v: View?, pos: Int, id: Long) { cb(opts[pos]) }
                    override fun onNothingSelected(p: AdapterView<*>) {}
                }
            })
            r.addView(tv(label, 11f, Color.WHITE).also { it.setPadding(8.dp, 0, 0, 0) })
        }
    }

    private fun btn(label: String, cb: () -> Unit): Button {
        return Button(context).apply {
            text = label; setTextColor(Color.WHITE); textSize = 11f
            setBackgroundColor(Color.parseColor("#CC880000"))
            setPadding(8.dp, 4.dp, 8.dp, 4.dp)
            layoutParams = LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(0, 2.dp, 4.dp, 2.dp) }
            setOnClickListener { cb() }
        }
    }

    private fun row(vararg v: View) = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; v.forEach { addView(it) } }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(context).apply { text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun sp(dp: Int) = View(context).apply { layoutParams = LayoutParams(MATCH_PARENT, dp.dp) }

    private fun save() {
        config.save(mapOf("espAtivo" to espAtivo, "espLinha" to espLinha, "espCaixa" to espCaixa, "espEsqueleto" to espEsqueleto, "espNome" to espNome, "espVida" to espVida, "aimbotAtivo" to aimbotAtivo, "puxarParedes" to puxarParedes, "exibirFov" to exibirFov, "fovValue" to fovValue, "noRecoil" to noRecoil, "ossoPuxada" to ossoPuxada))
    }

    private fun load() {
        val c = config.load()
        espAtivo = c["espAtivo"] as? Boolean ?: false; espLinha = c["espLinha"] as? Boolean ?: false
        espCaixa = c["espCaixa"] as? Boolean ?: false; espEsqueleto = c["espEsqueleto"] as? Boolean ?: false
        espNome = c["espNome"] as? Boolean ?: false; espVida = c["espVida"] as? Boolean ?: false
        aimbotAtivo = c["aimbotAtivo"] as? Boolean ?: false; puxarParedes = c["puxarParedes"] as? Boolean ?: false
        exibirFov = c["exibirFov"] as? Boolean ?: false; fovValue = (c["fovValue"] as? Double)?.toFloat() ?: 180f
        noRecoil = c["noRecoil"] as? Boolean ?: false; ossoPuxada = c["ossoPuxada"] as? String ?: "Cabeça"
    }

    private val Int.dp: Int get() = (this * context.resources.displayMetrics.density).toInt()
}
